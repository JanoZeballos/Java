import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Service {
	
    public void insertData(Data data) {

        Connection conexion = null;
        PreparedStatement preparedStmtInsercion = null;

        try {

            conexion = ConnectionManager.getConnection();
            
            //Definir la tabla como una variable y tambien las columnas
            
            preparedStmtInsercion = conexion.prepareStatement("INSERT INTO usuarios"
                    + "(NIP_USUARIO,CLAVE_USUARIO,SALDO_USUARIO,SALDO_CAJERO) VALUES "
                    + "(?,?,?)");
            preparedStmtInsercion.setString(1, data.getName());
            preparedStmtInsercion.setString(2, data.getLastName());
            preparedStmtInsercion.setString(3, data.getAddress());
            preparedStmtInsercion.execute();

        } catch (ReflectiveOperationException | SQLException ex) {
            Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (preparedStmtInsercion != null) {
                try {
                    preparedStmtInsercion.close();
                    conexion.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public void insertList(List<Data> data) {

        Connection conexion = null;

        try {
            conexion = ConnectionManager.getConnection();
            conexion.setAutoCommit(false);

            for (Data datas : data) {
            	insertData(datas);
            }
            conexion.commit();
        } catch (ReflectiveOperationException | SQLException e) {
            try {
                conexion.rollback();
            } catch (SQLException ee) {
            }
        } finally {
            try {
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException e) {
            }
        }
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
