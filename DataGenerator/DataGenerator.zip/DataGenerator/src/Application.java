
public class Application {

	public static void main(String[] args) {
		
		Data data = new Data();
		
		data.fillNameList();
		data.fillLastNameList();
		data.fillAddressList();

	}

}
