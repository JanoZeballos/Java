import java.util.ArrayList;
import java.util.List;

public class Data {

	private int countnames = 0;
	private int countlastname = 0;
	private int countaddress = 0;
	private List<String> name = new ArrayList<>();
	private List<String> lastname = new ArrayList<>();
	private List<String> address = new ArrayList<>();
	
	public void fillNameList(){
		name.add("David");
		name.add("Hernan");
		name.add("Facundo");
		name.add("German");
		name.add("Mauro");
		name.add("Laura");
		name.add("Pedro");
		name.add("Micaela");
		name.add("Miguel");
		name.add("Sofia");
	}
	
	public void fillLastNameList(){
		lastname.add("Mendez");
		lastname.add("Perez");
		lastname.add("Mendoza");
		lastname.add("Larrari");
		lastname.add("Firro");
		lastname.add("Finds");
		lastname.add("Dominguez");
		lastname.add("Tienio");
		lastname.add("Hundigo");
		lastname.add("Ernes");
	}
	
	public void fillAddressList(){
		address.add("Avenida Ac");
		address.add("Callao");
		address.add("Ramirez");
		address.add("Corrientes");
		address.add("Palermo");
		address.add("Citizen");
		address.add("Sinmu");
		address.add("Olimpo");
		address.add("Yuhi");
		address.add("Poiet");
	}
	
	public String getName(){
		countnames++;
		return name.get(countnames);
	}
	
	public String getLastName(){
		countlastname++;
		return lastname.get(countlastname);
	}
	
	public String getAddress(){
		countaddress++;
		return address.get(countaddress);
	}
	
	
	
	
	
}
