import java.util.List;

public class Personaje {
	
	private String nombre;
	private int vida;
	private Arma arma;
	private Armadura armadura;
	private List<Item> inventario;
	private EstadoPersonaje estado;
	
	public Personaje(String nombre, int vida, Arma arma, Armadura armadura, List<Item> inventario,
			EstadoPersonaje estado) {
		this.nombre = nombre;
		this.vida = vida;
		this.arma = arma;
		this.armadura = armadura;
		this.inventario = inventario;
		this.estado = estado;
	}
	
	public void hacerDanio(Personaje personaje){
		if(personaje.getVida() > 0){
			personaje.recibirDanio(personaje,this.estado.realizarAcciones(this.getArma().getDaniobase()));
		}else{
			personaje.recibirDanio(personaje,0);
		}
	}
	
	public void recibirDanio(Personaje personaje,int danio){
		if(personaje.getArmadura() != null){
			if(personaje.getArmadura().getDefensa() >= danio){

			}else{
				int daniorestar = danio - personaje.getArmadura().getDefensa();
				personaje.setVida(personaje.getVida() - daniorestar);
			}
		}else{
			personaje.setVida(personaje.getVida() - danio);
		}
	}
	
	public void a�adirItemInventario(Item item){
		inventario.add(item);
	}
	
	public void utilizarItem(Item item){
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public Arma getArma() {
		return arma;
	}

	public void setArma(Arma arma) {
		this.arma = arma;
	}

	public Armadura getArmadura() {
		return armadura;
	}

	public void setArmadura(Armadura armadura) {
		this.armadura = armadura;
	}

	public List<Item> getInventario() {
		return inventario;
	}

	public void setInventario(List<Item> inventario) {
		this.inventario = inventario;
	}

	public EstadoPersonaje getEstado() {
		return estado;
	}

	public void setEstado(EstadoPersonaje estado) {
		this.estado = estado;
	}
	
	

}
