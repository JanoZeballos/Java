
public class Armadura extends Item{

	private int defensa;
	
	public Armadura(String nombreItem, int defensa) {
		super(nombreItem);
		this.defensa = defensa;
	}

	public void equipar(Personaje personaje){
		personaje.setArmadura(this);
	}

	public int getDefensa() {
		return defensa;
	}

	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}
	
	
}
