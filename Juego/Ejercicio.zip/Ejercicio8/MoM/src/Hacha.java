
public class Hacha extends Arma{

	private int daniobase;
	private float porcentajecritico;
	
	public Hacha(String nombreItem, int daniobase, int daniobaseHacha, float porcentajecritico) {
		super(nombreItem, daniobase);
		this.daniobase = daniobaseHacha;
		this.porcentajecritico = porcentajecritico;
	}

	public boolean golpeCritico(){
		return porcentajecritico == 100;
	}

	public int getDaniobase() {
		return daniobase;
	}

	public void setDaniobase(int daniobase) {
		this.daniobase = daniobase;
	}

	public float getPorcentajecritico() {
		return porcentajecritico;
	}

	public void setPorcentajecritico(float porcentajecritico) {
		this.porcentajecritico = porcentajecritico;
	}
	
	
	
}
