
public interface EstadoPersonaje {

	public int realizarAcciones(int daniobase);
	
}
