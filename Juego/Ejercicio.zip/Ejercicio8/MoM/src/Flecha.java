
public class Flecha {

	private int daniobase;
	private int cantdeflechas;

	public Flecha(int daniobase, int cantdeflechas) {
		this.daniobase = daniobase;
		this.cantdeflechas = cantdeflechas;
	}

	public void equipar(Arco arco){
		arco.setFlecha(this);
	}

	public int getDaniobase() {
		return daniobase;
	}

	public void setDaniobase(int daniobase) {
		this.daniobase = daniobase;
	}

	public int getCantdeflechas() {
		return cantdeflechas;
	}

	public void setCantdeflechas(int cantdeflechas) {
		this.cantdeflechas = cantdeflechas;
	}
	
	
}
