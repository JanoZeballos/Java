import java.util.List;

public abstract class Item{
	
	private String nombre;
	
	public Item(String nombreItem){
		this.nombre = nombreItem;
	}
	
	public abstract void equipar(Personaje personaje);

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	

}
