
public class Espada {
	
	private int daniobase;

	public Espada(int daniobase) {
		this.daniobase = daniobase;
	}

	public int getDaniobase() {
		return daniobase;
	}

	public void setDaniobase(int daniobase) {
		this.daniobase = daniobase;
	}
	
	

}
