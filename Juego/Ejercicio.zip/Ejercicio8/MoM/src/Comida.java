
public class Comida extends Item{

	private int cantdevidacurar;
	private int cantdeusos;

	public Comida(String nombreItem, int cantdevidacurar, int cantdeusos) {
		super(nombreItem);
		this.cantdevidacurar = cantdevidacurar;
		this.cantdeusos = cantdeusos;
	}

	public void equipar(Personaje personaje){
		if(cantdeusos > 0){
			personaje.setVida(this.cantdevidacurar + personaje.getVida());
		}
	}


	public int getCantdevidacurar() {
		return cantdevidacurar;
	}


	public void setCantdevidacurar(int cantdevidacurar) {
		this.cantdevidacurar = cantdevidacurar;
	}


	public int getCantdeusos() {
		return cantdeusos;
	}


	public void setCantdeusos(int cantdeusos) {
		this.cantdeusos = cantdeusos;
	}
	
	
	
}
