
public class Muerto implements EstadoPersonaje{

	@Override
	public int realizarAcciones(int daniobase) {
		return 0;
	}

}
