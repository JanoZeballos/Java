import java.util.List;

public class Arma extends Item{

	private int daniobase;
	
	public Arma(String nombreItem, int daniobase) {
		super(nombreItem);
		this.daniobase = daniobase;
	}
	
	public void equipar(Personaje personaje){
		personaje.setArma(this);
	}

	public int getDaniobase() {
		return daniobase;
	}

	public void setDaniobase(int daniobase) {
		this.daniobase = daniobase;
	}
	
	
}
