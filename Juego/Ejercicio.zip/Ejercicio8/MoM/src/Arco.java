
public class Arco extends Arma{

	private Flecha flecha;
	private int daniobase;

	public Arco(String nombreItem, int daniobase, Flecha flecha, int daniobaseArco) {
		super(nombreItem, daniobase);
		this.flecha = flecha;
		this.daniobase = daniobaseArco;
	}

	public boolean tieneFlechas(){
		return flecha.getCantdeflechas() > 0;
	}

	public int getDaniobase() {
		return daniobase + flecha.getDaniobase();
	}

	public void setDaniobase(int daniobase) {
		this.daniobase = daniobase;
	}

	public Flecha getFlecha() {
		return flecha;
	}

	public void setFlecha(Flecha flecha) {
		this.flecha = flecha;
	}
	
	
}
