
public class Herido implements EstadoPersonaje{

	@Override
	public int realizarAcciones(int daniobase) {
		return daniobase / 2;
	}

}
