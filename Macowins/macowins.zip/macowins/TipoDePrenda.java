package macowins;


public class TipoDePrenda {
    
}
