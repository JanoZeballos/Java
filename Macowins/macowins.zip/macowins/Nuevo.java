package macowins;

public class Nuevo implements Estado { 

    @Override
    public double calcularPrecio(double precioBase) {
        return precioBase;
    }
}
