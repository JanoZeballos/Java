package macowins;


public class Tarjeta implements FormaDePago{

    private int cantCuotas;
    private double coeficiente = 1;
    
    public Tarjeta(int cantCuotas) {
        this.cantCuotas = cantCuotas;
    }
    
    @Override
    public double total(double precioBase) {
        return cantCuotas * coeficiente + 1.001 * precioBase;
    }
}
