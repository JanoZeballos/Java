
package macowins;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class Macowins {


    public static void main(String[] args) {
       
        Promocion promoVerano = new Promocion(50);
        
        Prenda jean = new Prenda(800, promoVerano, Prenda.Tipo.PANTALON);
        Prenda camisaGris = new Prenda(500, null, Prenda.Tipo.CAMISA);
        Prenda sacoLoco = new Prenda(1500, new Nuevo(), Prenda.Tipo.SACO);
        
        Collection<Item> prendasDeJuan = new ArrayList<>();
        prendasDeJuan.add(new Item(jean,1));
        prendasDeJuan.add(new Item(camisaGris,2));
        prendasDeJuan.add(new Item(sacoLoco,1));
        
        Date hoy = new Date();
        Venta venta = new Venta(prendasDeJuan, new Visa(3), hoy);
        System.out.println(venta.ganancia(hoy));
        
    }
    
}
