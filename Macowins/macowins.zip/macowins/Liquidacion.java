package macowins;

public class Liquidacion implements Estado {
    
    //Devuelve el 50% del valor base
    @Override
    public double calcularPrecio(double precioBase) {
       return precioBase/2;
    }
    
}
