package macowins;

public interface FormaDePago {
    public double total(double precioBase);
}
