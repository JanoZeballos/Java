package macowins;

public class Efectivo implements FormaDePago {

    @Override
    public double total(double precioBase) {
        return precioBase;
    }
    
    
}
