package macowins;

public class Prenda {
    public enum Tipo {PANTALON, CAMISA, SACO};
    private double precio;
    private Estado estado;
    //private TipoDePrenda tipo;
    private Tipo tipo;
    
    public Prenda(double precio, Estado estado, Tipo tipo) {
        this.precio = precio;
        this.estado = estado;
        this.tipo = tipo;        
    }

    public double getPrecio() {
        return precio/0;
    }
    
    
    public double calcularPrecio() {
        return estado.calcularPrecio(precio);
    }
}
