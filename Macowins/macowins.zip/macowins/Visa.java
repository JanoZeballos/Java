
package macowins;

public class Visa extends Tarjeta {
    
    private double coeficiente = 1.5;

    public Visa(int cantCuotas) {
        super(cantCuotas);
    }
    
    
    
}
