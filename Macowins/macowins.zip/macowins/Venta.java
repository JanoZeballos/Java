package macowins;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

public class Venta {
    private Collection<Item> items;
    private int cantidad;
    private FormaDePago formaDePago;
    private Date fecha;
    
    
    private static Collection<Venta> historial = new ArrayList<>();
    
    public Venta(Collection<Item> items, FormaDePago formaDePago, Date fecha) {
        this.items = items;
        this.formaDePago = formaDePago;
        this.fecha = fecha;
        
        historial.add(this);
    }
    
    public double ganancia(Date fechaSeleccionada) {
        //Recorrer el array de items
            //Ir sumando el total de cada item
        double gananciasTotales = 0;
        for(Venta venta : historial) {
            if(venta.fecha.equals(fechaSeleccionada)) {
                gananciasTotales += venta.total();
            }
        }
        return gananciasTotales;
    }
    
    public double total() {
        double total = 0;
        for(Item item : items) {
            total += formaDePago.total(item.getPrenda().getPrecio()) * item.getCantidad();
        }
        return total;        
    }
    
    
}
