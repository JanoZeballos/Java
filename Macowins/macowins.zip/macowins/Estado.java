package macowins;

public interface Estado {
    public double calcularPrecio(double precioBase);
}
