
public class Normal implements EstadoTarjeta{

	@Override
	public boolean puedeRetirar(int monto) {
		System.out.println("Puede retirar normalmente" + " Monto:" + monto);
		return true;
	}

}
