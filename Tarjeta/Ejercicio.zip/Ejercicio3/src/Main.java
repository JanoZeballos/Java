
public class Main {

	public static void main(String[] args) {
		
		TarjetaDeCredito tarjeta = new TarjetaDeCredito();

		tarjeta.setEstadotarjeta(new Rojo());
		tarjeta.puedeRetirar(800);

	}

}
