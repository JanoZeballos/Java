
public class Rojo implements EstadoTarjeta{

	@Override
	public boolean puedeRetirar(int monto) {
		if(monto>1000){
			System.out.println("No puede retirar mas que 1000" + " Monto:" + monto);
			return false;
		}else{
			System.out.println("Estado rojo puede retirar" + " Monto:" + monto);
			return true;
		}
	}

}
