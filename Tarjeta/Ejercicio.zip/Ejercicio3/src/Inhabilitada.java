
public class Inhabilitada implements EstadoTarjeta{

	@Override
	public boolean puedeRetirar(int monto) {
		System.out.println("No puede retirar inhabilitada" + " Monto:" + monto);
		return false;
	}

}
