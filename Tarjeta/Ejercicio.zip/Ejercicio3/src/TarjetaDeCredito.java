
public class TarjetaDeCredito{
	
	private EstadoTarjeta estadotarjeta;
	
	public boolean puedeRetirar(int monto) {
		return estadotarjeta.puedeRetirar(monto);	
	}
	
	public void setEstadotarjeta(EstadoTarjeta estadotarjeta){
		this.estadotarjeta = estadotarjeta;
	}

}
