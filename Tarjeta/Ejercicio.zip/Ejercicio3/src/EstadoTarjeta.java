
public interface EstadoTarjeta {
	
	public boolean puedeRetirar(int monto);

}
