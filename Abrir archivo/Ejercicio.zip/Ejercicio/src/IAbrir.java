
public interface IAbrir {
	
	public void abrir(Archivo archivo);

}
