
public class Visio implements IAbrir{

	@Override
	public void abrir(Archivo archivo) { 
		if(archivo.getExtension().equalsIgnoreCase("visio")){
			System.out.println("Abriendo..."+archivo.getNombre()+"."+archivo.getExtension());
		}
	}

}
