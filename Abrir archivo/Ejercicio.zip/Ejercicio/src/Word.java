
public class Word implements IAbrir{

	@Override
	public void abrir(Archivo archivo) {
		if(archivo.getExtension().equalsIgnoreCase("word")){
			System.out.println("Abriendo..."+archivo.getNombre()+"."+archivo.getExtension());
		}
	}

}
