
public class Photoshop implements IAbrir{

	@Override
	public void abrir(Archivo archivo) {
		if(archivo.getExtension().equalsIgnoreCase("photoshop")){
			System.out.println("Abriendo..."+archivo.getNombre()+"."+archivo.getExtension());
		}
	}

}
