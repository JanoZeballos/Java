
public class PDF implements IAbrir{

	@Override
	public void abrir(Archivo archivo) {
		if(archivo.getExtension().equalsIgnoreCase("PDF")){
			System.out.println("Abriendo..."+archivo.getNombre()+"."+archivo.getExtension());
		}
	}

}
