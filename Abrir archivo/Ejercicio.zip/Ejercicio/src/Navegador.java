
public class Navegador {

	public static void main(String[] args) {
		
		Archivo archivo = new Archivo("archivo","word");
		
		abrirArchivo(archivo);
		
		//new ???.abrir(archivo);

	}
	
	public static void abrirArchivo(Archivo archivo){
		if(archivo.getExtension().equalsIgnoreCase("visio")){
			new Visio().abrir(archivo);
		}else if(archivo.getExtension().equalsIgnoreCase("PDF")){
			new PDF().abrir(archivo);
		}else if(archivo.getExtension().equalsIgnoreCase("word")){
			new Word().abrir(archivo);
		}else if(archivo.getExtension().equalsIgnoreCase("photoshop")){
			new Photoshop().abrir(archivo);
		}
	}

}
