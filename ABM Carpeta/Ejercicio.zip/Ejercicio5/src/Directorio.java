
public abstract class Directorio {
	
	public String nombre;
	private Carpeta carpeta;
	
	public Directorio(String nombre, Carpeta carpeta) {
		this.nombre = nombre;
		this.carpeta = carpeta;
	}

	public abstract void agregarDirectorio(Directorio directorio);
	
	public abstract void quitarDirectorio(Directorio directorio);
	
	public void Copiar(Carpeta carpeta){
		System.out.println("Copiaste la carpeta: "+ carpeta.getNombre());
	}
	
	public void Eliminar(){
		System.out.println("Eliminaste el directorio: "+ nombre);
	}
	
	public void Mover(Carpeta carpeta){
		System.out.println("Moviste la carpeta: "+ carpeta.getNombre());
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Carpeta getCarpeta() {
		return carpeta;
	}

}
