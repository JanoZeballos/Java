
public class Aplicacion {

	public static void main(String[] args) {
		
		Carpeta carpeta1 = new Carpeta("C:/", null);
		
		carpeta1.agregarCarpeta("Windows");
		
		//carpeta1.agregarDirectorio(new Carpeta("DAS", carpeta1));
		
		

	}

}
