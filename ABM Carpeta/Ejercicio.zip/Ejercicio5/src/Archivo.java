
public class Archivo extends Directorio{

	private String nombre;
	private Carpeta carpeta;
	
	public Archivo(String nombre, Carpeta carpeta) {
		super(nombre, carpeta);
	}
	
	public void Copiar(Carpeta carpeta){
		System.out.println("Copiaste el archivo: "+ carpeta.getNombre());
	}
	
	public void Mover(Carpeta carpeta){
		System.out.println("Moviste el archivo: "+ carpeta.getNombre());
	}
	
	public void Eliminar(){
		System.out.println("Eliminaste el archivo: "+ carpeta.getNombre());
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public void agregarDirectorio(Directorio directorio) {
		
	}

	@Override
	public void quitarDirectorio(Directorio directorio) {
		
	}
	
	
}
