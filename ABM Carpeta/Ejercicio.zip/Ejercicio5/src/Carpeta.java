import java.util.ArrayList;
import java.util.List;

public class Carpeta extends Directorio{
	
	private List<Directorio> directorios = new ArrayList<>();
	
	public Carpeta(String nombre, Carpeta carpeta){
		super(nombre,carpeta);
	}
	
	public void agregarCarpeta(String nombre){
		directorios.add(new Carpeta(nombre,this));
	}
	
	public void agregarDirectorio(Directorio directorio){
		directorios.add(directorio);
	}
	
	public void quitarDirectorio(Directorio directorio){
		directorios.remove(directorio);
	}

	public void Copiar(Carpeta carpeta){
		System.out.println("Copiaste la carpeta: "+ carpeta.getNombre());
	}
	
	public void Eliminar(){
		System.out.println("Eliminaste la carpeta: "+ this.nombre);
	}
	
	public void moverCarpeta(Carpeta carpeta){
		System.out.println("Moviste la carpeta: "+ carpeta.getNombre());
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
}
