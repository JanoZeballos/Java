
public class Motor {

	public void Encender(){
		System.out.println("Encendido");
	}
	
	public void Acelerar(){
		System.out.println("Acelerando");
	}
	
	public void Apagar(){
		System.out.println("Apagado");
	}
	
}
