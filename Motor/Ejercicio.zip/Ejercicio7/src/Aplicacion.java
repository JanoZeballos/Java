import java.util.ArrayList;
import java.util.List;

public class Aplicacion {

	public static void main(String[] args) {
		
		List<Motor> motores = new ArrayList<>();
		

	}

}
