
public class MotorElectricoAdapter {

	public void Encender(){
		System.out.println("Encendido electrico");
	}
	
	public void Acelerar(){
		System.out.println("Acelerando electrico");
	}
	
	public void Apagar(){
		System.out.println("Apagado electrico");
	}
	
}
