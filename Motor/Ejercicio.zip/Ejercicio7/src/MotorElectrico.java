
public class MotorElectrico extends Motor{
	
	MotorElectricoAdapter motorelectrico;
	
	public void Encender(){
		motorelectrico.Encender();
	}
	
	public void Acelerar(){
		motorelectrico.Acelerar();
	}
	
	public void Apagar(){
		motorelectrico.Apagar();
	}

}
