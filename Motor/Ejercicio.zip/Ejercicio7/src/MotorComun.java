
public class MotorComun extends Motor{
	
	@Override
	public void Encender(){
		System.out.println("Encendido");
	}
	
	@Override
	public void Acelerar(){
		System.out.println("Acelerando");
	}
	
	@Override
	public void Apagar(){
		System.out.println("Apagado");
	}
	
}
