package clase5;

public abstract class Raton {
    private double posicion;

    public Raton(double pos) {
        posicion = pos;
    }
    public double posicion() { return posicion; }
    public abstract double velocidad();
}
