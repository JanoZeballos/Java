package clase5;

public class RobotRaton extends Raton{

    public RobotRaton(double pos) {
        super(pos);
    }

    @Override
    public double velocidad() {
        return 8;
    }
    
}
