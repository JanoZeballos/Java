package clase5;

public interface Alcanzable {
   public double velocidad();
   public double posicion();
}
