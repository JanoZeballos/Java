package clase5;
public class Tom implements Alcanzable {
    private double posicion;
    private int energia; 
    @Override
    public double velocidad() {
        return 5 + energia /10;
    }
    @Override
    public double posicion() {
        return posicion;
    }
    public void correrA(Alcanzable bicho) {
        if(velocidad() > bicho.velocidad()) {
            energia -=  0.5 * velocidad(); //* distancia.entre(posicion, raton.posicion())
            posicion = bicho.posicion();
        }
    }
}


