package clase5;

public class Jerry extends Raton {
    double peso;
    public Jerry(double peso, double posicion) {
        super(posicion);
        this.peso = peso;
    }
    @Override
    public double velocidad() {
        return peso + 5 / 3;
    }
}
