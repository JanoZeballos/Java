package contestador;

import java.util.HashMap;
import java.util.Map;

public class Contestador {
 
    private Map<String, String> respuestas;
    
    public Contestador() {
        respuestas = new HashMap<>();
        inicializarRespuestas();
    }
    
    public String responderA(String nombre) {
        return respuestas.getOrDefault(nombre,
                "Ahora no estoy, por favor llame mas tarde.");
        
        
        /*return respuestas.get(nombre) == null 
                ? "Llame luego" : respuestas.get(nombre);
        */
        
        
        /*
        String respuesta;
        switch(nombre) {
            case "Juan":
                respuesta = "Ola ke ase";
                break;
            case "Pedro":
                respuesta = "Te llamo mas tarde";
                break;
            default:
                respuesta = "Me comunico con usted mas tarde";
                break;
        }*/
        
        /*Forma menos eficiente de resolverlo
        if(nombre.equals("Juan")) {
            respuesta = "Ola ke ase";
        } 
        else if(nombre.equals("Pedro")) {
            respuesta = "Te llamo despues";
        }
        else {
            respuesta = "Me comunico con usted mas tarde";
        }
        return respuesta;
        */
    }

    public void agregarRespuesta(String nombre, String respuesta) {
        respuestas.put(nombre, respuesta);
    }
            
    private void inicializarRespuestas() {
        respuestas.put("Juan", "Ola ke ase");
        respuestas.put("Pepe", "Acordate de ir al dentista");
        respuestas.put("Cami", "Nos vemos el martes");
    }
}
