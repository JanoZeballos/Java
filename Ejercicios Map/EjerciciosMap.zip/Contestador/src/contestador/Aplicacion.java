package contestador;

public class Aplicacion {

    public static void main(String[] args) {
        Contestador miContestador = new Contestador();
        System.out.println(miContestador.responderA("Juan"));
        
        System.out.println(miContestador.responderA("Euge"));
        
        miContestador.agregarRespuesta("Euge", "hola!");
        System.out.println(miContestador.responderA("Euge"));
           
    }
    
}
