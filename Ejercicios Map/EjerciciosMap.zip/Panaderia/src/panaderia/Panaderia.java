package panaderia;

import java.util.LinkedList;
import java.util.Queue;


public class Panaderia {
  
  Queue<Cliente> cola = new LinkedList<>();
  LogeadorPorArchivo logeador = new LogeadorPorArchivo();
  
  public void entrar(Cliente cliente) {
    cola.offer(cliente);
    logeador.escribir("Entro " + cliente.getNombre() + " y pago " + cliente.getMonto());
  }
  
  public Cliente atender() {
    Cliente cliente = cola.poll();
    logeador.escribir("Se atendio a " + cliente.getNombre());
    return cliente;
  }
    
  public Queue<Cliente> enEspera() {
    return cola;
  }
}
