package panaderia;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LogeadorPorArchivo implements Logeador {

    private static String ARCHIVO_DE_LOG = "panaderia.log";
    private static FileWriter fw;
    
    public void escribir(String texto) {
        try {
            fw = new FileWriter(new File(ARCHIVO_DE_LOG), true);
            fw.write(new Date().toString() + " " + texto + "\r\n");
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
