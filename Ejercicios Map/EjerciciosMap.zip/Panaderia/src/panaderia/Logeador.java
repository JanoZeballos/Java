package panaderia;

public interface Logeador {
    public void escribir(String texto);
}
