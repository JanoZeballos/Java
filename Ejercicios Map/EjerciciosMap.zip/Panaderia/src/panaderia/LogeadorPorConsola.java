package panaderia;

public class LogeadorPorConsola implements Logeador{
    
    public void escribir(String texto) {
        System.out.println(texto);
    }
}
