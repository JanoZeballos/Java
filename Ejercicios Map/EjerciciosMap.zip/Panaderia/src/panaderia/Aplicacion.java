
package panaderia;

import java.util.Locale;
import java.util.Scanner;

public class Aplicacion {

    private static LogeadorPorConsola logeadorConsolero = new LogeadorPorConsola();
    public static void main(String[] args) {
     
        Panaderia panaderia = new Panaderia();
        while(true) {
            panaderia.entrar(ingresarCliente());
        }
    }
    
    public static Cliente ingresarCliente() {
        Scanner sc = new Scanner(System.in).useLocale(Locale.US);  
        System.out.flush();        
        logeadorConsolero.escribir("Ingrese su nombre");
        String nombre = sc.next();  
        logeadorConsolero.escribir("Ingrese su pago");  
        double pago = sc.nextDouble();  
        Cliente nuevoCliente = new Cliente(nombre, pago);
        return nuevoCliente;
    }
    
}
