package empanadas;

import static empanadas.Pedido.Gusto.*;

public class Aplicacion {

    public static void main(String[] args) {
        Pedido pedidoLunes = new Pedido();
        pedidoLunes.anotar(JAMON_Y_QUESO);
        pedidoLunes.anotar(CARNE_SUAVE);
        pedidoLunes.anotar(PERRO);
        pedidoLunes.anotar(CARNE_SUAVE);
        pedidoLunes.anotar(CARNE_SUAVE);
        //pedidoLunes.anotar("Sarasa"); //JA!
        System.out.println(pedidoLunes.gustos().toString());
    }
    
}
