
package empanadas;

import java.util.HashMap;
import java.util.Map;


public class Pedido {
    
    Map<Gusto, Integer> empanadas = new HashMap<>();
    public enum Gusto {CARNE_SUAVE, JAMON_Y_QUESO, PERRO};
    
    public void anotar(Gusto gusto) {
        int valor = empanadas.getOrDefault(gusto, 0); //wrapper
        empanadas.put(gusto, valor + 1);
        /*Integer valor = empanadas.get(gusto); //wrapper
        if(valor == null) {
            empanadas.put(gusto, 1);
        } else {
            empanadas.put(gusto, valor + 1);
        }*/
    }
    
    public Map<Gusto, Integer> gustos() {
        return empanadas;
    }
    
}
