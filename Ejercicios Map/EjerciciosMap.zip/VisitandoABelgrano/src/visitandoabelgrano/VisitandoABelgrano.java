package visitandoabelgrano;


public class VisitandoABelgrano {

    public static void main(String[] args) {
        LibroDeSugerencias libro = new LibroDeSugerencias();
        libro.registrarSugerencia("33401...", "Me encantó el Museo!");
        libro.registrarSugerencia("41110...", "Bart estuvo aquí");
        libro.registrarSugerencia("29323...", "Agreguen más ilumincación, por favor");
        libro.registrarSugerencia("41110...", "Bart estuvo aquí, de nuevo");
        System.out.println(libro.sugerencias());

    }
    
}
