
package visitandoabelgrano;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class LibroDeSugerencias {

    private Set<Integer> dnis;
    private List<String> sugerencias;
    
    public LibroDeSugerencias() {
        this.dnis = new HashSet<>();
        this.sugerencias = new ArrayList<>();
    }
    
    public void registrarSugerencia(String dni, String sugerencia) {
        dnis.add(dni.hashCode());
        sugerencias.add(sugerencia);
    }
    
    public String sugerencias() {
        return sugerencias.toString();
    }
    
    public int cantidadDnisUnicos() {
        return dnis.size();
    }
}
