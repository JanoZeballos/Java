import java.util.ArrayList;
import java.util.List;

public class Ourtube {

	public static void main(String[] args) {
	
	Usuario usuario = new Usuario("Juan");
	Usuario usuario2 = new Usuario("Martin");
	
	usuario.suscribirse(usuario2);
	
	usuario2.subirVideo();

	}

}
