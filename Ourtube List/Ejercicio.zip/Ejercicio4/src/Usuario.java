import java.util.ArrayList;
import java.util.List;

public class Usuario {

	private String username;
	
	List<Usuario> listaseguidos = new ArrayList<>();
	List<Usuario> listaseguidores = new ArrayList<>();
	
	public Usuario(String username){
		this.username = username;
	}
	
	public void subirVideo(){
		System.out.println("Nuevo video!");
		notificar();
	}
	
	public void notificar(){
		for(Usuario listaseguidor : listaseguidores){
			listaseguidor.recibirAviso(this);
		}
	}
	
	public void suscribirse(Usuario usuario){
		listaseguidos.add(usuario);
		usuario.listaseguidores.add(this);
		System.out.println("Te suscribiste a: "+ usuario.getUsername() + " Enhorabuena: "+ this.getUsername());
	}
	
	public void desuscribirse(Usuario usuario){
		listaseguidos.remove(usuario);
		usuario.listaseguidores.remove(this);
		System.out.println("Te desuscribiste a: "+ usuario);
	}
	
	public void recibirAviso(Usuario usuario){
		System.out.println(usuario.getUsername() + " subio un video");
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
	
}
