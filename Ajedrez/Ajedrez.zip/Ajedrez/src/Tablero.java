package src;


public class Tablero {
	
	//private tablero int [][]=new int[8][8]; 
	private static Figura Tablero [][]=new Figura[8][8];

    static void chocoFigu(int f, int c, int fDest, int cDest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void comer(int i, int cDest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
	
	Tablero()
	{
		/*
                for(int i=0;i<8;i++)
		{
			Tablero[1][i]=new Peon( 1,  i,false, "Peon");
		}
		
		for(int i=0;i<8;i++)
		{
			Tablero[6][i]=new Peon( 6,  i,true, "Peon");
		}
		*/
		Tablero[0][0]=new Torre( 0,  0,false, "Torre");
		Tablero[0][7]=new Torre( 0,  7,false, "Torre");
		
		Tablero[7][0]=new Torre( 7,  0,true, "Torre");
		Tablero[7][7]=new Torre( 7,  7,true, "Torre");
		
		Tablero[0][1]=new Caballo( 0,  1,false, "Caballo");
		Tablero[0][6]=new Caballo( 0,  6,false, "Caballo");
		
		Tablero[7][1]=new Caballo( 7,  1,true, "Caballo");
		Tablero[7][6]=new Caballo( 7,  6,true, "Caballo");
		
		Tablero[0][2]=new Alfil( 0,  2,false, "Alfil");
		Tablero[0][5]=new Alfil( 0,  5,false, "Alfil");
		
		Tablero[7][2]=new Alfil( 7,  2,true, "Alfil");
		Tablero[7][5]=new Alfil( 7,  5,true, "Alfil");
		
		Tablero[0][3]=new Reina( 0,  3,false, "Reina");
		Tablero[7][3]=new Reina( 7,  3,true, "Reina");
		
		Tablero[0][4]=new Rey( 0,  4,false, "Rey");
		Tablero[7][4]=new Rey( 7,  4,true, "Rey");	
	}
	
	
	public void TableroMostrar()
	{
		for(int f=0;f<8;f++)
		{
			for(int c=0;c<8;c++)
			{
				if(Tablero[f][c]==null)
				{
					System.out.print("<["+f+"]"+"["+c+"]>"+"\t");
				}else
				{
					System.out.print(Tablero[f][c].getNombreColor()+
							"["+f+"]"+"["+c+"]"+
							"  ");
				}
	
			}
			System.out.print("\n");
		}
		
		System.out.print("\n"+"\n"+"\n");
	}

	public static Figura getFigu(int f,int c)
	{
		return(Tablero[f][c]);
	}
	
	public static void chFigu(int fOrig,int cOrig,int fDest,int cDest)
	{
		Tablero[fDest][cDest]=Tablero[fOrig][cOrig];
		Tablero[fOrig][cOrig]=null;
	}
	
        public static void promocion(int f,int c,String fichaACrear)
        {
            boolean color= Tablero[f][c].colorBlancas;
                    
                    if(fichaACrear.equalsIgnoreCase("reina"))
                    {
                    Tablero[f][c]=new Reina(f,c,color,"reina");
                    }
        }
	
	
	
}
