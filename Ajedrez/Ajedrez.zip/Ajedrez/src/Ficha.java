package src;


public class Ficha 
{
	protected int f=0;
	protected int c=0;
	protected boolean colorBlancas=false;
	
	Ficha(int f,int c,boolean colorBlancas)
	{
		this.f=f;
		this.c=c;
		this.colorBlancas=colorBlancas;
	}
	
	public void setColorBlancas(boolean color)
	{
		this.colorBlancas=color;
	}
	
	public String getColorBlancas()
	{
		if(this.colorBlancas)
		{
			return("blanco");
		}else
		{
			return("negro");
		}
	}

}
