package src;


public class Persona 
{
	protected String nom1;
	protected String ape1;
	protected int dni;
	
	Persona(String nom,String ape,int dni)
	{
		nom1=nom;
		ape1=ape;
		this.dni=dni;
	}
}
