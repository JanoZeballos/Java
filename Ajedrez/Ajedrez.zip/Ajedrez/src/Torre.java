package src;


public class Torre extends Figura {

    Torre(int f, int c, boolean colorBlancas, String nom) {
        super(f, c, colorBlancas, nom);
    }

    public void mover(int fDest, int cDest) {
        int i, j;
        int pasos = 0;
        Figura figu = null;
        //misma columna y avanza
        if (cDest == c && fDest > f) {
            pasos = (fDest - f);
            for (i = 1; i <= pasos; i++) {
                figu = getFigura(f + 1, c);
                if (figu == null) {
                    avanzarUnPasoMismaColumna();
                } else {
                    figu.sacar(colorBlancas);
                    avanzarUnPasoMismaColumna();
                }
            }
        }
        
        // misma columna  y retrocede
        if (cDest == c && fDest < f) {
            pasos = (f - fDest);
            for (i = 1; i <= pasos; i++) {
                figu = getFigura(f - 1, c);
                if (figu == null) {
                    retrocederUnPasoMismaColumna();
                } else {
                    figu.sacar(colorBlancas);
                    retrocederUnPasoMismaColumna();
                }
            }
        }
        
        //misma fila y avanza
        if (fDest == f && cDest > c) {
            pasos = (cDest - c);
            for (i = 1; i <= pasos; i++) {
                figu = Tablero.getFigu(f, c + 1); 
                if (figu == null) {
                    avanzarUnPasoMismaFila();
                } else {
                    figu.sacar(colorBlancas);
                    avanzarUnPasoMismaFila();
                }
            }
        }
        
        // misma fila y retrocede
        if (fDest == f && cDest < c) {
            pasos = (c - cDest);
            for (i = 1; i <= pasos; i++) {
                figu = Tablero.getFigu(f, c - 1); 
                if (figu == null) {
                    retrocederUnPasoMismaFila();
                } else {
                    figu.sacar(colorBlancas);
                    retrocederUnPasoMismaFila();
                }
            }
        }
        
    }

    private void retrocederUnPasoMismaFila() {
        Tablero.chFigu(f, c, f, c - 1);
        c = c - 1;
    }

    private void avanzarUnPasoMismaFila() {
        Tablero.chFigu(f, c, f, c + 1);
        c = c + 1;
    }

    private void retrocederUnPasoMismaColumna() {
        Tablero.chFigu(f, c, f - 1, c);
        f = f - 1;
    }

    private void avanzarUnPasoMismaColumna() {
        Tablero.chFigu(f, c, f + 1, c);
        f = f + 1;
    }

    private Figura getFigura(int fila, int columna) {
        Figura figu = Tablero.getFigu(fila, columna);
        return figu;
    }
}
