package src;

public class Reina extends Figura
{//por Alan Manganaro + Facundo Margulies
	Reina (int f, int c,boolean colorBlancas, String nom)
	{
		super(f,c,colorBlancas,nom);
	}
	
	
	public void mover(int fDest,int cDest)
	{
		int o=0;
		int p=0;
		boolean comioOLlegoAOtraPieza = false;
		if (c==cDest){//movimiento vertical
			if (f<fDest) {
				o=1;
			}else if(f==fDest){
				comioOLlegoAOtraPieza=true;
			}else if(f>fDest){
				o=-1;
			}
			while (comioOLlegoAOtraPieza==false) {
				System.out.println(f+" "+c+" "+fDest+" "+cDest+" "+o);
				if (f==fDest) {
					comioOLlegoAOtraPieza=true;//llego a destino
				}
				else if (f<fDest) {//para que la reina baje
					if (Tablero.getFigu(f+o, cDest)==null) {
						Tablero.chFigu(f, c, f+o, cDest);
						f=f+o;
					}else{
						if (this.colorBlancas==Tablero.getFigu(f+o, cDest).colorBlancas) {
							System.out.println("Es tu ficha!!");
							comioOLlegoAOtraPieza=true;
						}else{
							comioOLlegoAOtraPieza=true;
							Tablero.comer(f+o, cDest);
							Tablero.chFigu(f, c, f+o, cDest);
							f=f+o;
						}
					}
				}
				else if(f>fDest){//para que la reina suba
					System.out.println(f+" "+c+" "+fDest+" "+cDest+" "+o);
					if (f==fDest) {
						comioOLlegoAOtraPieza=true;//llego a destino
					}
					else if (f>fDest) {//para que la reina baje
						if (Tablero.getFigu(f+o, cDest)==null) {
							Tablero.chFigu(f, c, f+o, cDest);
							f=f+o;
						}else{
							System.out.println(fDest+" "+c);
							if (this.colorBlancas==Tablero.getFigu(f+o, cDest).colorBlancas) {
								comioOLlegoAOtraPieza=true;
								System.out.println("Es tu ficha!!");
							}else{
								comioOLlegoAOtraPieza=true;
								Tablero.comer(f+o, cDest);
								Tablero.chFigu(f, c, f+o, cDest);
								f=f+o;
							}
						}
					}					
				}
			}
		}else if(f==fDest){//movimiento horizontal
			if (c<cDest) {
				o=1;
			}else if(c==cDest){
				comioOLlegoAOtraPieza=true;
			}else if(c>cDest){
				o=-1;
			}
			while (comioOLlegoAOtraPieza==false) {
				System.out.println(f+" "+c+" "+fDest+" "+cDest+" "+o);
				if (c==cDest) {
					comioOLlegoAOtraPieza=true;//llego a destino
				}
				else if (c<cDest) {//para que la reina se mueva a la derecha
					if (Tablero.getFigu(fDest, c+o)==null) {
						Tablero.chFigu(f, c, fDest, c+o);
						c=c+o;
					}else{
						if (this.colorBlancas==Tablero.getFigu(fDest, c+o).colorBlancas) {
							System.out.println("Es tu ficha!!");
							comioOLlegoAOtraPieza=true;
						}else{
							comioOLlegoAOtraPieza=true;
							Tablero.comer(fDest, c+o);
							Tablero.chFigu(f, c, fDest, c+o);
							c=c+o;
						}
					}
				}
				else if(c>cDest){//para que la reina se mueva a la izquierda
					System.out.println(f+" "+c+" "+fDest+" "+cDest+" "+o);
					if (c==cDest) {
						comioOLlegoAOtraPieza=true;//llego a destino
					}
					else if (c>cDest) {//para que la reina baje
						if (Tablero.getFigu(fDest, c+o)==null) {
							Tablero.chFigu(f, c, fDest, c+o);
							c=c+o;
						}else{
							System.out.println(fDest+" "+c);
							if (this.colorBlancas==Tablero.getFigu(fDest, c+o).colorBlancas) {
								comioOLlegoAOtraPieza=true;
								System.out.println("Es tu ficha!!");
							}else{
								comioOLlegoAOtraPieza=true;
								Tablero.comer(fDest, c+o);
								Tablero.chFigu(f, c, fDest, c+o);
								c=c+o;
							}
						}
					}					
				}
			}			
		}else if(fDest-f==cDest-c){//diagonal abajo derecha
			o=1;
			while (comioOLlegoAOtraPieza==false) {
				System.out.println(f+" "+c+" "+fDest+" "+cDest+" "+o);
				if (c==cDest&&f==fDest) {
					comioOLlegoAOtraPieza=true;//llego a destino
				}else if (c<cDest&&f<fDest) {
					if (Tablero.getFigu(fDest, c+o)==null) {
						Tablero.chFigu(f, c, f+o, c+o);
						c=c+o;
						f=f+o;
					}else{
						if (this.colorBlancas==Tablero.getFigu(f+o, c+o).colorBlancas) {
							System.out.println("Es tu ficha!!");
							comioOLlegoAOtraPieza=true;
						}else{
							comioOLlegoAOtraPieza=true;
							Tablero.comer(f+o, c+o);
							Tablero.chFigu(f, c, f+o, c+o);
							c=c+o;
							f=f+o;
						}
					}
				}
			}	
		}
	}
				/*
				fDest-f==cDest-c || //diagonal abajo derecha
				fDest+f==cDest-c || //diagonal abajo izquierda
				fDest-f==cDest+c || //diagonal arriba derecha
				fDest+f==cDest+c)   //diagonal arriba izquierda 
				*/
		
	
}