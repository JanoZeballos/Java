package src;

public class Caballo extends Figura
{
	Caballo (int f, int c,boolean colorBlancas, String nom)
	{
		super(f,c,colorBlancas,nom);
	}
	
	
	
	//Follonier
	//Alves
	//Ortuvia
		
	
	public void mover(int fDest,int cDest)
	{
		if(( (fDest<=f+2)&&(fDest<=7)&&(cDest==c-1)&&(colorBlancas==false) )||((fDest<=f+2)&&(fDest<=7)&&(cDest==c+1)&&(colorBlancas==false) )||
			( (fDest>=f-2)&&(fDest>=0)&&(cDest==c-1)&&(colorBlancas==true)  ) ||( (fDest>=f-2)&&(fDest>=0)&&(cDest==c+1)&&(colorBlancas==true)  )||
			( (cDest<=c+2)&&(cDest<=7)&&(fDest==f-1)&&(colorBlancas==false) )|| ( (cDest<=c+2)&&(cDest<=7)&&(fDest==f+1)&&(colorBlancas==true)  ) ||
			( (cDest>=c-2)&&(cDest>=0)&&(fDest==f-1)&&(colorBlancas==false) )|| ( (cDest>=c-2)&&(cDest>=0)&&(fDest==f+1)&&(colorBlancas==true)  )){
				Tablero.chFigu(f, c, fDest, cDest);
				f=fDest;
				c=cDest;
				
		

		}else{
			f=f;
			c=c;
			System.out.println("Movimiento invalido");
		}


}


}