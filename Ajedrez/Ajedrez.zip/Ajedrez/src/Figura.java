package src;


public class Figura extends Ficha 
{
	private String nombre;
	
	Figura (int f, int c,boolean colorBlancas, String nom)
	{
		super(f,c,colorBlancas);
		nombre=nom;
	}
	
	public String getNombreColor()
	{
		String nombreColor;
		nombreColor=nombre +" "+super.getColorBlancas();
		return(nombreColor);
	}
	
	public void mover()
	{
		
	}

    void sacar(boolean color) {
        if (colorBlancas != color) {
            f = -1;
            c = -1;
        }
    }
	
}
