package src;


import javax.swing.JOptionPane;

public class Jugador extends Persona {

    private boolean colorBlanco;
    private double tiempoTotal;
    private double tini = 0;
    private double tfin = 0;

    Jugador(String nom, String ape, int dni, String colorBlanco) {
        super(nom, ape, dni);

        this.colorBlanco = (colorBlanco == "blanco") ? true : false;

    }

    public void Jugar() {
        int fini = 0, cini = 0, fdes = 0, cdes = 0;
        Figura figu;

        // Validamos que la figura en el origen exista para poder continuar
        do {
            fini = Integer.parseInt((JOptionPane.showInputDialog(null, ((colorBlanco == true) ? "blanco " : "negro ") + "Ingrese fila inicial de la figura a mover")));
            cini = Integer.parseInt((JOptionPane.showInputDialog(null, ((colorBlanco == true) ? "blanco " : "negro ") + "Ingrese col inicial de la figura a mover")));
            fdes = Integer.parseInt((JOptionPane.showInputDialog(null, ((colorBlanco == true) ? "blanco " : "negro ") + "Ingrese fila final de la figura a mover")));
            cdes = Integer.parseInt((JOptionPane.showInputDialog(null, ((colorBlanco == true) ? "blanco " : "negro ") + "Ingrese col final de la figura a mover")));
            figu = Tablero.getFigu(fini, cini);
        } while (figu == null);

        if (figu.colorBlancas == colorBlanco) {
            if (figu instanceof Peon) {
                ((Peon) figu).mover(fdes, cdes);
            }
            if (figu instanceof Alfil) {
                ((Alfil) figu).mover(fdes, cdes);
            }
            if (figu instanceof Caballo) {
                ((Caballo) figu).mover(fdes, cdes);
            }
            if (figu instanceof Reina) {
                ((Reina) figu).mover(fdes, cdes);
            }
            if (figu instanceof Rey) {
                ((Rey) figu).mover(fdes, cdes);
            }
            if (figu instanceof Torre) {
                ((Torre) figu).mover(fdes, cdes);
            }
        }
    }
}
