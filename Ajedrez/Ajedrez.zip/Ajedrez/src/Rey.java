package src;

public class Rey extends Figura{
	
	//Rocio alvarez, Gustavo Farias
		
	protected int dDest=0;
	Rey(int f, int c, boolean colorNegro, String nom) {
		super(f, c, colorNegro, nom);
	}
	public void mover(int fDest,int cDest)
	{
		if(Tablero.getFigu(fDest, cDest)==null)
		{
			if(((fDest==f+1) && (fDest<=7)) || ((fDest==f-1) && (fDest>=0)))
			{
				Tablero.chocoFigu(f, c, fDest, cDest);
				f=fDest; 
		}
			else if (((cDest==c+1) && (cDest<=7)) || ((cDest==c-1) && (cDest>=0)))
			{
				Tablero.chocoFigu(f, c, fDest, cDest);
				c=cDest;
		}
			else if (((fDest==f+1) && (fDest<=7) && (cDest==c+1) && (cDest<=7)) ||
					((fDest==f+1) && (fDest<=7) && (cDest==c-1) && (cDest>=0)) ||
					((fDest==f-1) && (fDest>=0) && (cDest==c-1) && (cDest>=0)) ||
					((fDest==f-1) && (fDest>=0) && (cDest==c+1) && (cDest<=7)))
			{
				Tablero.chocoFigu(f, c, fDest, cDest);
				dDest=cDest+fDest;
	}
}
	}
}
