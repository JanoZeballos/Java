package src;


public class Ajedrez
{

	public static void main(String[] args) 
	{
                Tablero t=new Tablero();
                t.TableroMostrar();
                Jugador j1=new Jugador("juan","carlos",123,"blanco");
                Jugador j2=new Jugador("Bautista","Grand",123,"negro");
                while (true){
                j1.Jugar();
                t.TableroMostrar();
                j2.Jugar();
                t.TableroMostrar();
                }
                
                
                
            
		
	}

}
