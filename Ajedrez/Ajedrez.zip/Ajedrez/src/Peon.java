package src;


import javax.swing.JOptionPane;

public class Peon extends Figura {

    private boolean promocion = false;
    private boolean primerMovimiento = true;

    Peon(int f, int c, boolean colorBlancas, String nom) {
        super(f, c, colorBlancas, nom);
    }

    public void mover(int fDest, int cDest) {
        String ficha;
        if ((c == cDest) && Tablero.getFigu(fDest, cDest) == null) {

        }

        if (primerMovimiento == true) {
            if (((fDest <= f + 2) && (fDest <= 7) && (colorBlancas == false)) || ((fDest >= f - 2) && (fDest >= 0) && (colorBlancas == true))) {
                Tablero.chFigu(f, c, fDest, cDest);
                f = fDest;
                primerMovimiento = false;
                if (fDest == 7 || fDest == 0) {
                    promocion = true;
                }
            }
        } else {
            if (((fDest <= f + 1) && (fDest <= 7))  || ((fDest >= f - 1) && (fDest >= 0))) {
                if ((colorBlancas == true && fDest < f) && (colorBlancas == false && fDest > f)) {
                    Tablero.chFigu(f, c, fDest, cDest);
                    f = fDest;
                    primerMovimiento = false;
                    if (fDest == 7 || fDest == 0) {
                        promocion = true;
                    }
                }

            }
        }

        if (promocion == true) {
            ficha = JOptionPane.showInputDialog(null, "Elija ficha para promocion");

            Tablero.promocion(f, c, ficha);
        }

    }

}
