package src;

public class Alfil extends Figura {

	Alfil(int f, int c, boolean colorBlancas, String nom) {
		super(f, c, colorBlancas, nom);
	}

	public void mover(int fDest, int cDest) {

		boolean comiollego = false;

		// Diagonal abajo DERECHA
		
		if ((fDest > f && cDest > c) && (fDest - f == cDest - c)) {
			while (comiollego == false) {
				if (fDest == f && cDest == c) {
					comiollego = true;
				} else if (fDest > f && cDest > c) {
					if (Tablero.getFigu(f + 1, c + 1) == null) {
						Tablero.chFigu(f, c, f + 1, c + 1);
						f = f + 1;
						c = c + 1;
					} else {
						if (this.colorBlancas == Tablero.getFigu(f + 1, c + 1).colorBlancas) {
							comiollego = true;
						} else {
							comiollego = true;
							Tablero.comer(f + 1, c + 1);
							Tablero.chFigu(f, c, f + 1, c + 1);
							f = f + 1;
							c = c + 1;
						}
					}
				}
			}
		}
		// Diagonal abajo IZQUIERDA
		if ((fDest > f && cDest < c) && (fDest - f == c - cDest)) {
			while (comiollego == false) {
				if (fDest == f && cDest == c) {
					comiollego = true;
				} else if (fDest > f && cDest < c) {
					if (Tablero.getFigu(f + 1, c - 1) == null) {
						Tablero.chFigu(f, c, f + 1, c - 1);
						f = f + 1;
						c = c - 1;
					} else {
						if (this.colorBlancas == Tablero.getFigu(f + 1, c - 1).colorBlancas) {
							comiollego = true;
						} else {
							comiollego = true;
							Tablero.comer(f + 1, c - 1);
							Tablero.chFigu(f, c, f + 1, c - 1);
							f = f + 1;
							c = c - 1;
						}
					}
				}
			}
		}
		// Diagonal arriba IZQUIERDA
		if ((fDest < f && cDest < c) && (f - fDest == c - cDest)) {
			while (comiollego == false) {
				if (fDest == f && cDest == c) {
					comiollego = true;
				} else if (fDest < f && cDest < c) {
					if (Tablero.getFigu(f - 1, c - 1) == null) {
						Tablero.chFigu(f, c, f - 1, c - 1);
						f = f - 1;
						c = c - 1;
					} else {
						if (this.colorBlancas == Tablero.getFigu(f - 1, c - 1).colorBlancas) {
							comiollego = true;
						} else {
							comiollego = true;
							Tablero.comer(f - 1, c - 1);
							Tablero.chFigu(f, c, f - 1, c - 1);
							f = f - 1;
							c = c - 1;
						}
					}
				}
			}
		}
		// Diagonal arriba DERECHA
		if ((fDest < f && cDest > c) && (f - fDest == cDest - c)) {
			while (comiollego == false) {
				if (fDest == f && cDest == c) {
					comiollego = true;
				} else if (fDest < f && cDest > c) {
					if (Tablero.getFigu(f - 1, c + 1) == null) {
						Tablero.chFigu(f, c, f - 1, c + 1);
						f = f - 1;
						c = c + 1;
					} else {
						if (this.colorBlancas == Tablero.getFigu(f - 1, c + 1).colorBlancas) {
							comiollego = true;
						} else {
							comiollego = true;
							Tablero.comer(f - 1, c + 1);
							Tablero.chFigu(f, c, f - 1, c + 1);
							f = f - 1;
							c = c + 1;
						}
					}
				}
			}
		}
	}
}

/*
 * (fDest-f==cDest-c) //Diagonal abajo derecha (fDest+f==cDest-c) //Diagonal
 * abajo izquierda (fDest-f==cDest+c) //Diagonal arriba derecha
 * (fDest+f==cDest+c) //Diagonal arriba izquierda
 */