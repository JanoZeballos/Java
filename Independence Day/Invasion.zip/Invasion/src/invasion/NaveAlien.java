
package invasion;
public class NaveAlien extends Nave {
    private double escudo; 
    public NaveAlien(double danio, double armadura, Arma arma, double escudo) {
        super(danio, armadura, arma);
        this.escudo = escudo;
    }
    protected void recibirAtaque(double danio) {
        if(escudo - danio > 0) {
            escudo = escudo - danio;
        } else {
            escudo = 0;
            danio = escudo - danio;
            if(armadura - danio > 0) {
                armadura = armadura - danio;    
            } else {
                armadura = 0;
            }
        }
    }
}
