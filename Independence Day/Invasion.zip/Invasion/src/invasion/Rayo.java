
package invasion;


public class Rayo extends Arma {
    public Rayo() {
        super(100);
    }
}
