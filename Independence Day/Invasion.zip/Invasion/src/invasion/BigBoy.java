package invasion;

public class BigBoy extends Arma {
    
    private static int existencias = 4;
    
    public BigBoy() {
        super(10000);
    }
    
    public double calcularDanioTotal(double danioBase) {
        if(existencias > 0) {
            existencias--;
            return danio;
        } else {
            return 0;
        }
    }  
    
}
