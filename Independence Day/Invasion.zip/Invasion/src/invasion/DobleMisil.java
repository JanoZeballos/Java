
package invasion;

public class DobleMisil extends Arma {
    public DobleMisil() {
        super(0);
    }
    
    public double calcularDanioTotal(double danioBase) {
        return danioBase * 2;
    }
}
