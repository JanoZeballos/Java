
package invasion;


public class LaserProgresivo extends Arma {
    
    int cargas;
    
    public LaserProgresivo(int cargas) {
        super(100);
        this.cargas = cargas;
    }
    
    public double calcularDanioTotal(double danioBase) {
        if(cargas > 0) {
            return danioBase * danio / cargas--;
        } else {
            return 0;
        }
    }   
    
}
