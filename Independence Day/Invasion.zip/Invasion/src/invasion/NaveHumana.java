package invasion;
public class NaveHumana extends Nave {
    
    public NaveHumana(double danio, double armadura, Arma arma) {
        super(danio, armadura, arma);
    }
    
    protected void recibirAtaque(double danio) {
        if(armadura - danio > 0) {
            armadura = armadura - danio; 
            this.danioBase += danio;
        } else {
            armadura = 0;
        }
    }
}
