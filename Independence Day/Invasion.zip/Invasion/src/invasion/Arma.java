package invasion;

public class Arma {
    protected double danio;
    
    public Arma(double danio) {
        this.danio = danio;
    }
    
    public double getDanio() {
        return danio;
    }
    
    public double calcularDanioTotal(double danioBase) {
        return danioBase + danio;
    }
}
