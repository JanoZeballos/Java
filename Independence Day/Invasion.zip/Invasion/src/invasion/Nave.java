
package invasion;


public abstract class Nave {
    protected double danioBase;
    protected double armadura;
    protected Arma arma;
    
    public Nave(double danio, double armadura, Arma arma) {
        this.danioBase = danio;
        this.armadura = armadura;
        this.arma = arma;
    }
    
    public boolean puedeCombatir() {
        return armadura > 0;
    }
    
    protected abstract void recibirAtaque(double danio);
    
    public void atacar(Nave naveDefensora) {
        if(naveDefensora.puedeCombatir() && this.puedeCombatir()) {
            naveDefensora.recibirAtaque(calcularDanioTotal());
        }
    }
    
   public double calcularDanioTotal() {
       return arma.calcularDanioTotal(danioBase);
   }
    
}
